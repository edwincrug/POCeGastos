﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eGastosEntity.Ultimus
{
    public class UltRequester
    {
        public DateTime requesterDate { get; set; }
        public string requesterEmail { get; set; }
        public string requesterLogin { get; set; }
        public string requesterName { get; set; }
    }
}
