﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eGastosEntity.Ultimus
{
    public class UltGlobal
    {
        public int idSession { get; set; }
        public string treasuryComments { get; set; }
    }
}
