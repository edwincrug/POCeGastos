﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eGastosEntity.Ultimus
{
    public class UltFlobotVariables
    {
        public string messageError { get; set; }
        public string messageErrorAgency { get; set; }
        public int status { get; set; }
        public int statusAgencyFlobot { get; set; }
    }
}
