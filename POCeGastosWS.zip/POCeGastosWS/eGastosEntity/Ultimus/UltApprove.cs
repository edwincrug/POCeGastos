﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eGastosEntity.Ultimus
{
    public class UltApprove
    {
        public bool approved { get; set; }
        public string approverEmail { get; set; }
        public string approverLogin { get; set; }
        public string approverName { get; set; }
    }
}
