﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eGastosEntity.Ultimus
{
    public class UltResponsible
    {
        public string responsibleEmail { get; set; }
        public string responsibleLogin { get; set; }
        public string responsibleName { get; set; }
    }
}
