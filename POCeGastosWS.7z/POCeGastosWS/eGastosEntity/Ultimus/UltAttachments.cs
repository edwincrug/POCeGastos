﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eGastosEntity.Ultimus
{
    public class UltAttachments
    {
        public string Description { get; set; }
        public DateTime FileDate { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string FileType { get; set; }
        public string Username { get; set; }
    }
}
